// Template, IGAD version 2
// IGAD/NHTV/UU - Jacco Bikker - 2006-2020

#include "precomp.h"

#define STB_IMAGE_IMPLEMENTATION
#define STBI_NO_PSD
#define STBI_NO_PIC
#define STBI_NO_PNM
#include "lib/stb_image.h"

#pragma comment( linker, "/subsystem:windows /ENTRY:mainCRTStartup" )

using namespace Tmpl8;

// Enable usage of dedicated GPUs in notebooks
// Note: this does cause the linker to produce a .lib and .exp file;
// see http://developer.download.nvidia.com/devzone/devcenter/gamegraphics/files/OptimusRenderingPolicies.pdf
#ifdef WIN32
extern "C"
{
	__declspec(dllexport) unsigned long NvOptimusEnablement = 0x00000001;
}

extern "C"
{
	__declspec(dllexport) int AmdPowerXpressRequestHighPerformance = 1;
}
#endif

static bool hasFocus = true, running = true;
static GLTexture* renderTarget = 0;
static int scrwidth = 0, scrheight = 0;
static TheApp* app = 0;
static SDL_Window* window = 0;
static Surface* surface = 0;

// static member data for instruction set support class
static const CPUCaps cpucaps;

// find the app implementation
TheApp* CreateApp();

// Application entry point
int main( int argc, char** argv )
{
#if 0
	// open a window
	if (!glfwInit()) FatalError( "glfwInit failed." );
	glfwSetErrorCallback( ErrorCallback );
	glfwWindowHint( GLFW_CONTEXT_VERSION_MAJOR, 3 ); // 3.3 is enough for our needs
	glfwWindowHint( GLFW_CONTEXT_VERSION_MINOR, 3 );
	glfwWindowHint( GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE );
	glfwWindowHint( GLFW_STENCIL_BITS, GL_FALSE );
	glfwWindowHint( GLFW_RESIZABLE, GL_FALSE /* easier :) */ );
#ifdef FULLSCREEN
	window = glfwCreateWindow( SCRWIDTH, SCRHEIGHT, "Tmpl8-2022", glfwGetPrimaryMonitor(), 0 );
#else
	window = glfwCreateWindow( SCRWIDTH, SCRHEIGHT, "Tmpl8-2022", 0, 0 );
#endif
	if (!window) FatalError( "glfwCreateWindow failed." );
	glfwMakeContextCurrent( window );
	// register callbacks
	glfwSetWindowSizeCallback( window, ReshapeWindowCallback );
	glfwSetKeyCallback( window, KeyEventCallback );
	glfwSetWindowFocusCallback( window, WindowFocusCallback );
	glfwSetMouseButtonCallback( window, MouseButtonCallback );
	glfwSetScrollCallback( window, MouseScrollCallback );
	glfwSetCursorPosCallback( window, MousePosCallback );
	glfwSetCharCallback( window, CharEventCallback );
	// initialize GLAD
	if (!gladLoadGLLoader( (GLADloadproc)glfwGetProcAddress )) FatalError( "gladLoadGLLoader failed." );
	glfwSwapInterval( 0 );
#else
	SDL_Init( SDL_INIT_VIDEO );
#ifdef FULLSCREEN
	window = SDL_CreateWindow( "Advgr_ALT_2022", 100, 100, SCRWIDTH, SCRHEIGHT, SDL_WINDOW_FULLSCREEN );
#else
	window = SDL_CreateWindow( "Advgr_ALT_2022", 100, 100, SCRWIDTH, SCRHEIGHT, SDL_WINDOW_SHOWN );
#endif
	surface = new Surface( SCRWIDTH, SCRHEIGHT );
	surface->Clear( 0 );
	SDL_Renderer* renderer = SDL_CreateRenderer( window, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC );
	SDL_Texture* frameBuffer = SDL_CreateTexture( renderer, SDL_PIXELFORMAT_ARGB8888, SDL_TEXTUREACCESS_STREAMING, SCRWIDTH, SCRHEIGHT );
#endif
	// we want a console window for text output
#ifndef FULLSCREEN
	CONSOLE_SCREEN_BUFFER_INFO coninfo;
	AllocConsole();
	GetConsoleScreenBufferInfo( GetStdHandle( STD_OUTPUT_HANDLE ), &coninfo );
	coninfo.dwSize.X = 1280;
	coninfo.dwSize.Y = 800;
	SetConsoleScreenBufferSize( GetStdHandle( STD_OUTPUT_HANDLE ), coninfo.dwSize );
	FILE* file = nullptr;
	freopen_s( &file, "CON", "w", stdout );
	freopen_s( &file, "CON", "w", stderr );
	SetWindowPos( GetConsoleWindow(), HWND_TOP, 0, 0, 1280, 800, 0 );
	SDL_RaiseWindow( window );
#endif
	// initialize application
	app = new Renderer();
	app->screen = surface;
	app->Init();
#if 0
	// prepare OpenGL state
	glDisable( GL_DEPTH_TEST );
	glDisable( GL_CULL_FACE );
	glDisable( GL_BLEND );
	CheckGL();
#endif
	// done, enter main loop
	float deltaTime = 0;
	static int frameNr = 0;
	static Timer timer;
	static bool exitapp = false;
	while (!exitapp)
	{
		deltaTime = min( 500.0f, 1000.0f * timer.elapsed() );
		timer.reset();
		app->Tick( deltaTime );
		void* target = 0;
		int pitch;
		SDL_LockTexture( frameBuffer, NULL, &target, &pitch );
		if (pitch == (surface->width * 4))
		{
			memcpy( target, surface->pixels, SCRWIDTH * SCRHEIGHT * 4 );
		}
		else
		{
			unsigned char* t = (unsigned char*)target;
			for (int i = 0; i < SCRHEIGHT; i++)
			{
				memcpy( t, surface->pixels + i * SCRWIDTH, SCRWIDTH * 4 );
				t += pitch;
			}
		}
		SDL_UnlockTexture( frameBuffer );
		SDL_RenderCopy( renderer, frameBuffer, NULL, NULL );
		SDL_RenderPresent( renderer );
		if (!running) break;
		// event loop
		SDL_Event event;
		while (SDL_PollEvent( &event ))
		{
			switch (event.type)
			{
			case SDL_QUIT:
				exitapp = 1;
				break;
			case SDL_KEYDOWN:
				if (event.key.keysym.sym == SDLK_ESCAPE)
				{
					exitapp = 1;
					// find other keys here: http://sdl.beuc.net/sdl.wiki/SDLKey
				}
				app->KeyDown( event.key.keysym.scancode );
				break;
			case SDL_KEYUP:
				app->KeyUp( event.key.keysym.scancode );
				break;
			case SDL_MOUSEMOTION:
				app->MouseMove( event.motion.x, event.motion.y );
				break;
			case SDL_MOUSEBUTTONUP:
				app->MouseUp( event.button.button );
				break;
			case SDL_MOUSEBUTTONDOWN:
				app->MouseDown( event.button.button );
				break;
			default:
				break;
			}
		}
	}
	// close down
	app->Shutdown();
	Kernel::KillCL();
	SDL_Quit();
	return 1;
}

// Jobmanager implementation
DWORD JobThreadProc( LPVOID lpParameter )
{
	JobThread* JobThreadInstance = (JobThread*)lpParameter;
	JobThreadInstance->BackgroundTask();
	return 0;
}

void JobThread::CreateAndStartThread( unsigned int threadId )
{
	m_GoSignal = CreateEvent( 0, FALSE, FALSE, 0 );
	m_ThreadHandle = CreateThread( 0, 0, (LPTHREAD_START_ROUTINE)&JobThreadProc, (LPVOID)this, 0, 0 );
	m_ThreadID = threadId;
}
void JobThread::BackgroundTask()
{
	while (1)
	{
		WaitForSingleObject( m_GoSignal, INFINITE );
		while (1)
		{
			Job* job = JobManager::GetJobManager()->GetNextJob();
			if (!job)
			{
				JobManager::GetJobManager()->ThreadDone( m_ThreadID );
				break;
			}
			job->RunCodeWrapper();
		}
	}
}

void JobThread::Go()
{
	SetEvent( m_GoSignal );
}

void Job::RunCodeWrapper()
{
	Main();
}

JobManager* JobManager::m_JobManager = 0;

JobManager::JobManager( unsigned int threads ) : m_NumThreads( threads )
{
	InitializeCriticalSection( &m_CS );
}

JobManager::~JobManager()
{
	DeleteCriticalSection( &m_CS );
}

void JobManager::CreateJobManager( unsigned int numThreads )
{
	m_JobManager = new JobManager( numThreads );
	m_JobManager->m_JobThreadList = new JobThread[numThreads];
	for (unsigned int i = 0; i < numThreads; i++)
	{
		m_JobManager->m_JobThreadList[i].CreateAndStartThread( i );
		m_JobManager->m_ThreadDone[i] = CreateEvent( 0, FALSE, FALSE, 0 );
	}
	m_JobManager->m_JobCount = 0;
}

void JobManager::AddJob2( Job* a_Job )
{
	m_JobList[m_JobCount++] = a_Job;
}

Job* JobManager::GetNextJob()
{
	Job* job = 0;
	EnterCriticalSection( &m_CS );
	if (m_JobCount > 0) job = m_JobList[--m_JobCount];
	LeaveCriticalSection( &m_CS );
	return job;
}

void JobManager::RunJobs()
{
	if (m_JobCount == 0) return;
	for (unsigned int i = 0; i < m_NumThreads; i++) m_JobThreadList[i].Go();
	WaitForMultipleObjects( m_NumThreads, m_ThreadDone, TRUE, INFINITE );
}

void JobManager::ThreadDone( unsigned int n )
{
	SetEvent( m_ThreadDone[n] );
}

DWORD CountSetBits( ULONG_PTR bitMask )
{
	DWORD LSHIFT = sizeof( ULONG_PTR ) * 8 - 1, bitSetCount = 0;
	ULONG_PTR bitTest = (ULONG_PTR)1 << LSHIFT;
	for (DWORD i = 0; i <= LSHIFT; ++i) bitSetCount += ((bitMask & bitTest) ? 1 : 0), bitTest /= 2;
	return bitSetCount;
}

void JobManager::GetProcessorCount( uint& cores, uint& logical )
{
	// https://github.com/GPUOpen-LibrariesAndSDKs/cpu-core-counts
	cores = logical = 0;
	char* buffer = NULL;
	DWORD len = 0;
	if (FALSE == GetLogicalProcessorInformationEx( RelationAll, (PSYSTEM_LOGICAL_PROCESSOR_INFORMATION_EX)buffer, &len ))
	{
		if (GetLastError() == ERROR_INSUFFICIENT_BUFFER)
		{
			buffer = (char*)malloc( len );
			if (GetLogicalProcessorInformationEx( RelationAll, (PSYSTEM_LOGICAL_PROCESSOR_INFORMATION_EX)buffer, &len ))
			{
				DWORD offset = 0;
				char* ptr = buffer;
				while (ptr < buffer + len)
				{
					PSYSTEM_LOGICAL_PROCESSOR_INFORMATION_EX pi = (PSYSTEM_LOGICAL_PROCESSOR_INFORMATION_EX)ptr;
					if (pi->Relationship == RelationProcessorCore)
					{
						cores++;
						for (size_t g = 0; g < pi->Processor.GroupCount; ++g)
							logical += CountSetBits( pi->Processor.GroupMask[g].Mask );
					}
					ptr += pi->Size;
				}
			}
			free( buffer );
		}
	}
}

JobManager* JobManager::GetJobManager()
{
	if (!m_JobManager)
	{
		uint c, l;
		GetProcessorCount( c, l );
		CreateJobManager( l );
	}
	return m_JobManager;
}

// OpenGL helper functions
void _CheckGL( const char* f, int l )
{
	GLenum error = glGetError();
	if (error != GL_NO_ERROR)
	{
		const char* errStr = "UNKNOWN ERROR";
		if (error == 0x500) errStr = "INVALID ENUM";
		else if (error == 0x502) errStr = "INVALID OPERATION";
		else if (error == 0x501) errStr = "INVALID VALUE";
		else if (error == 0x506) errStr = "INVALID FRAMEBUFFER OPERATION";
		FatalError( "GL error %d: %s at %s:%d\n", error, errStr, f, l );
	}
}

GLuint CreateVBO( const GLfloat* data, const uint size )
{
	GLuint id;
	glGenBuffers( 1, &id );
	glBindBuffer( GL_ARRAY_BUFFER, id );
	glBufferData( GL_ARRAY_BUFFER, size, data, GL_STATIC_DRAW );
	CheckGL();
	return id;
}

void BindVBO( const uint idx, const uint N, const GLuint id )
{
	glEnableVertexAttribArray( idx );
	glBindBuffer( GL_ARRAY_BUFFER, id );
	glVertexAttribPointer( idx, N, GL_FLOAT, GL_FALSE, 0, (void*)0 );
	CheckGL();
}

void CheckShader( GLuint shader, const char* vshader, const char* fshader )
{
	char buffer[1024];
	memset( buffer, 0, sizeof( buffer ) );
	GLsizei length = 0;
	glGetShaderInfoLog( shader, sizeof( buffer ), &length, buffer );
	CheckGL();
	FATALERROR_IF( length > 0 && strstr( buffer, "ERROR" ), "Shader compile error:\n%s", buffer );
}

void CheckProgram( GLuint id, const char* vshader, const char* fshader )
{
	char buffer[1024];
	memset( buffer, 0, sizeof( buffer ) );
	GLsizei length = 0;
	glGetProgramInfoLog( id, sizeof( buffer ), &length, buffer );
	CheckGL();
	FATALERROR_IF( length > 0, "Shader link error:\n%s", buffer );
}

void DrawQuad()
{
	static GLuint vao = 0;
	if (!vao)
	{
		// generate buffers
		static const GLfloat verts[] = { -1, 1, 0, 1, 1, 0, -1, -1, 0, 1, 1, 0, -1, -1, 0, 1, -1, 0 };
		static const GLfloat uvdata[] = { 0, 0, 1, 0, 0, 1, 1, 0, 0, 1, 1, 1 };
		GLuint vertexBuffer = CreateVBO( verts, sizeof( verts ) );
		GLuint UVBuffer = CreateVBO( uvdata, sizeof( uvdata ) );
		glGenVertexArrays( 1, &vao );
		glBindVertexArray( vao );
		BindVBO( 0, 3, vertexBuffer );
		BindVBO( 1, 2, UVBuffer );
		glBindVertexArray( 0 );
		CheckGL();
	}
	glBindVertexArray( vao );
	glDrawArrays( GL_TRIANGLES, 0, 6 );
	glBindVertexArray( 0 );
}

// OpenGL texture wrapper class
GLTexture::GLTexture( uint w, uint h, uint type )
{
	width = w;
	height = h;
	glGenTextures( 1, &ID );
	glBindTexture( GL_TEXTURE_2D, ID );
	if (type == DEFAULT)
	{
		// regular texture
		glTexImage2D( GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_BGR, GL_UNSIGNED_BYTE, 0 );
		glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST );
		glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST );
	}
	else if (type == INTTARGET)
	{
		glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE );
		glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE );
		glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST );
		glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST );
		glTexImage2D( GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, 0 );
	}
	else /* type == FLOAT */
	{
		// floating point texture
		glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE );
		glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE );
		glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST );
		glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST );
		glTexImage2D( GL_TEXTURE_2D, 0, GL_RGBA32F, width, height, 0, GL_RGBA, GL_FLOAT, 0 );
	}
	glBindTexture( GL_TEXTURE_2D, 0 );
	CheckGL();
}

GLTexture::~GLTexture()
{
	glDeleteTextures( 1, &ID );
	CheckGL();
}

void GLTexture::Bind( const uint slot )
{
	glActiveTexture( GL_TEXTURE0 + slot );
	glBindTexture( GL_TEXTURE_2D, ID );
	CheckGL();
}

void GLTexture::CopyFrom( Surface* src )
{
	glBindTexture( GL_TEXTURE_2D, ID );
	glTexImage2D( GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0, GL_BGRA, GL_UNSIGNED_BYTE, src->pixels );
	CheckGL();
}

void GLTexture::CopyTo( Surface* dst )
{
	glBindTexture( GL_TEXTURE_2D, ID );
	glGetTexImage( GL_TEXTURE_2D, 0, GL_RGBA, GL_UNSIGNED_BYTE, dst->pixels );
	CheckGL();
}

// Shader class implementation
Shader::Shader( const char* vfile, const char* pfile, bool fromString )
{
	if (fromString)
	{
		Compile( vfile, pfile );
	}
	else
	{
		Init( vfile, pfile );
	}
}

Shader::~Shader()
{
	glDetachShader( ID, pixel );
	glDetachShader( ID, vertex );
	glDeleteShader( pixel );
	glDeleteShader( vertex );
	glDeleteProgram( ID );
	CheckGL();
}

void Shader::Init( const char* vfile, const char* pfile )
{
	string vsText = TextFileRead( vfile );
	string fsText = TextFileRead( pfile );
	FATALERROR_IF( vsText.size() == 0, "File %s not found", vfile );
	FATALERROR_IF( fsText.size() == 0, "File %s not found", pfile );
	const char* vertexText = vsText.c_str();
	const char* fragmentText = fsText.c_str();
	Compile( vertexText, fragmentText );
}

void Shader::Compile( const char* vtext, const char* ftext )
{
	vertex = glCreateShader( GL_VERTEX_SHADER );
	pixel = glCreateShader( GL_FRAGMENT_SHADER );
	glShaderSource( vertex, 1, &vtext, 0 );
	glCompileShader( vertex );
	CheckShader( vertex, vtext, ftext );
	glShaderSource( pixel, 1, &ftext, 0 );
	glCompileShader( pixel );
	CheckShader( pixel, vtext, ftext );
	ID = glCreateProgram();
	glAttachShader( ID, vertex );
	glAttachShader( ID, pixel );
	glBindAttribLocation( ID, 0, "pos" );
	glBindAttribLocation( ID, 1, "tuv" );
	glLinkProgram( ID );
	CheckProgram( ID, vtext, ftext );
	CheckGL();
}

void Shader::Bind()
{
	glUseProgram( ID );
	CheckGL();
}

void Shader::Unbind()
{
	glUseProgram( 0 );
	CheckGL();
}

void Shader::SetInputTexture( uint slot, const char* name, GLTexture* texture )
{
	glActiveTexture( GL_TEXTURE0 + slot );
	glBindTexture( GL_TEXTURE_2D, texture->ID );
	glUniform1i( glGetUniformLocation( ID, name ), slot );
	CheckGL();
}

void Shader::SetInputMatrix( const char* name, const mat4& matrix )
{
	const GLfloat* data = (const GLfloat*)&matrix;
	glUniformMatrix4fv( glGetUniformLocation( ID, name ), 1, GL_FALSE, data );
	CheckGL();
}

void Shader::SetFloat( const char* name, const float v )
{
	glUniform1f( glGetUniformLocation( ID, name ), v );
	CheckGL();
}

void Shader::SetInt( const char* name, const int v )
{
	glUniform1i( glGetUniformLocation( ID, name ), v );
	CheckGL();
}

void Shader::SetUInt( const char* name, const uint v )
{
	glUniform1ui( glGetUniformLocation( ID, name ), v );
	CheckGL();
}

// RNG - Marsaglia's xor32
static uint seed = 0x12345678;
uint WangHash( uint s ) 
{ 
	s = (s ^ 61) ^ (s >> 16);
	s *= 9, s = s ^ (s >> 4);
	s *= 0x27d4eb2d;
	s = s ^ (s >> 15); 
	return s; 
}
uint InitSeed( uint seedBase )
{
	return WangHash( (seedBase + 1) * 17 );
}
uint RandomUInt()
{
	seed ^= seed << 13;
	seed ^= seed >> 17;
	seed ^= seed << 5;
	return seed;
}
float RandomFloat() { return RandomUInt() * 2.3283064365387e-10f; }
float Rand( float range ) { return RandomFloat() * range; }
// local seed
uint RandomUInt( uint& seed )
{
	seed ^= seed << 13;
	seed ^= seed >> 17;
	seed ^= seed << 5;
	return seed;
}
float RandomFloat( uint& seed ) { return RandomUInt( seed ) * 2.3283064365387e-10f; }

// Perlin noise implementation - https://stackoverflow.com/questions/29711668/perlin-noise-generation
static int numX = 512, numY = 512, numOctaves = 7, primeIndex = 0;
static float persistence = 0.5f;
static int primes[10][3] = {
	{ 995615039, 600173719, 701464987 }, { 831731269, 162318869, 136250887 }, { 174329291, 946737083, 245679977 },
	{ 362489573, 795918041, 350777237 }, { 457025711, 880830799, 909678923 }, { 787070341, 177340217, 593320781 },
	{ 405493717, 291031019, 391950901 }, { 458904767, 676625681, 424452397 }, { 531736441, 939683957, 810651871 },
	{ 997169939, 842027887, 423882827 }
};
static float Noise( const int i, const int x, const int y )
{
	int n = x + y * 57;
	n = (n << 13) ^ n;
	const int a = primes[i][0], b = primes[i][1], c = primes[i][2];
	const int t = (n * (n * n * a + b) + c) & 0x7fffffff;
	return 1.0f - (float)t / 1073741824.0f;
}
static float SmoothedNoise( const int i, const int x, const int y )
{
	const float corners = (Noise( i, x - 1, y - 1 ) + Noise( i, x + 1, y - 1 ) + Noise( i, x - 1, y + 1 ) + Noise( i, x + 1, y + 1 )) / 16;
	const float sides = (Noise( i, x - 1, y ) + Noise( i, x + 1, y ) + Noise( i, x, y - 1 ) + Noise( i, x, y + 1 )) / 8;
	const float center = Noise( i, x, y ) / 4;
	return corners + sides + center;
}
static float Interpolate( const float a, const float b, const float x )
{
	const float ft = x * 3.1415927f, f = (1 - cosf( ft )) * 0.5f;
	return a * (1 - f) + b * f;
}
static float InterpolatedNoise( const int i, const float x, const float y )
{
	const int integer_X = (int)x, integer_Y = (int)y;
	const float fractional_X = x - integer_X, fractional_Y = y - integer_Y;
	const float v1 = SmoothedNoise( i, integer_X, integer_Y );
	const float v2 = SmoothedNoise( i, integer_X + 1, integer_Y );
	const float v3 = SmoothedNoise( i, integer_X, integer_Y + 1 );
	const float v4 = SmoothedNoise( i, integer_X + 1, integer_Y + 1 );
	const float i1 = Interpolate( v1, v2, fractional_X );
	const float i2 = Interpolate( v3, v4, fractional_X );
	return Interpolate( i1, i2, fractional_Y );
}
float noise2D( const float x, const float y )
{
	float total = 0, frequency = (float)(2 << numOctaves), amplitude = 1;
	for (int i = 0; i < numOctaves; ++i)
	{
		frequency /= 2, amplitude *= persistence;
		total += InterpolatedNoise( (primeIndex + i) % 10, x / frequency, y / frequency ) * amplitude;
	}
	return total / frequency;
}

// math implementations
float4::float4(const float3& a, const float d)
{
	x = a.x, y = a.y, z = a.z;
	w = d;
}
float4::float4(const float3& a)
{
	x = a.x, y = a.y, z = a.z;
	w = 0;
}
int4::int4(const int3& a, const int d)
{
	x = a.x, y = a.y, z = a.z;
	w = d;
}
uint4::uint4(const uint3& a, const uint d)
{
	x = a.x, y = a.y, z = a.z;
	w = d;
}
mat4 operator*(const mat4& a, const mat4& b)
{
	mat4 r;
	for (uint i = 0; i < 16; i += 4)
		for (uint j = 0; j < 4; ++j)
		{
			r[i + j] =
				(a.cell[i + 0] * b.cell[j + 0]) +
				(a.cell[i + 1] * b.cell[j + 4]) +
				(a.cell[i + 2] * b.cell[j + 8]) +
				(a.cell[i + 3] * b.cell[j + 12]);
		}
	return r;
}
mat4 operator*( const mat4& a, const float s )
{
	mat4 r;
	for (uint i = 0; i < 16; i += 4) r.cell[i] = a.cell[i] * s;
	return r;
}
mat4 operator*( const float s, const mat4& a )
{
	mat4 r;
	for (uint i = 0; i < 16; i++) r.cell[i] = a.cell[i] * s;
	return r;
}
mat4 operator+( const mat4& a, const mat4& b )
{
	mat4 r;
	for (uint i = 0; i < 16; i += 4) r.cell[i] = a.cell[i] + b.cell[i];
	return r;
}
bool operator==( const mat4& a, const mat4& b )
{
	for (uint i = 0; i < 16; i++)
		if (a.cell[i] != b.cell[i]) return false;
	return true;
}
bool operator!=( const mat4& a, const mat4& b ) { return !(a == b); }
float4 operator*( const mat4& a, const float4& b )
{
	return make_float4( a.cell[0] * b.x + a.cell[1] * b.y + a.cell[2] * b.z + a.cell[3] * b.w,
		a.cell[4] * b.x + a.cell[5] * b.y + a.cell[6] * b.z + a.cell[7] * b.w,
		a.cell[8] * b.x + a.cell[9] * b.y + a.cell[10] * b.z + a.cell[11] * b.w,
		a.cell[12] * b.x + a.cell[13] * b.y + a.cell[14] * b.z + a.cell[15] * b.w );
}
float4 operator*( const float4& b, const mat4& a )
{
	return make_float4( a.cell[0] * b.x + a.cell[1] * b.y + a.cell[2] * b.z + a.cell[3] * b.w,
		a.cell[4] * b.x + a.cell[5] * b.y + a.cell[6] * b.z + a.cell[7] * b.w,
		a.cell[8] * b.x + a.cell[9] * b.y + a.cell[10] * b.z + a.cell[11] * b.w,
		a.cell[12] * b.x + a.cell[13] * b.y + a.cell[14] * b.z + a.cell[15] * b.w );
}
float3 TransformPosition( const float3& a, const mat4& M )
{
	return make_float3( make_float4( a, 1 ) * M );
}
float3 TransformVector( const float3& a, const mat4& M )
{
	return make_float3( make_float4( a, 0 ) * M );
}

// Helper functions
bool FileIsNewer( const char* file1, const char* file2 )
{
	struct stat f1;
	struct stat f2;

	auto ret = stat( file1, &f1 );
	FATALERROR_IF( ret, "File %s not found!", file1 );

	if (stat( file2, &f2 )) return true; // second file does not exist

#ifdef _MSC_VER
	return f1.st_mtime >= f2.st_mtime;
#else
	if (f1.st_mtim.tv_sec >= f2.st_mtim.tv_sec)
		return true;
	return f1.st_mtim.tv_nsec >= f2.st_mtim.tv_nsec;
#endif
}

bool FileExists( const char* f )
{
	ifstream s( f );
	return s.good();
}

bool RemoveFile( const char* f )
{
	if (!FileExists( f )) return false;
	return !remove( f );
}

uint FileSize( string filename )
{
	ifstream s( filename );
	return s.good();
}

string TextFileRead( const char* _File )
{
	ifstream s( _File );
	string str( (istreambuf_iterator<char>( s )), istreambuf_iterator<char>() );
	s.close();
	return str;
}

int LineCount( const string s )
{
	const char* p = s.c_str();
	int lines = 0;
	while (*p) if (*p++ == '\n') lines++;
	return lines;
}

void TextFileWrite( const string& text, const char* _File )
{
	ofstream s( _File, ios::binary );
	int len = (int)text.size();
	s.write( (const char*)&len, sizeof( len ) );
	s.write( text.c_str(), len );
}

void FatalError( const char* fmt, ... )
{
	char t[16384];
	va_list args;
	va_start( args, fmt );
	vsnprintf( t, sizeof( t ), fmt, args );
	va_end( args );
#ifdef _MSC_VER
	MessageBox( NULL, t, "Fatal error", MB_OK );
#else
	fprintf( stderr, t );
#endif
	while (1) exit( 0 );
}

// source file information
static int sourceFiles = 0;
static char* sourceFile[64]; // yup, ugly constant

// default worksize
static size_t workSize[] = { SCRWIDTH, SCRHEIGHT };
static size_t localSize[] = { 32, 4 };

using namespace std;

#define CHECKCL(r) CheckCL( r, __FILE__, __LINE__ )

// CHECKCL method
// OpenCL error handling.
// ----------------------------------------------------------------------------
bool CheckCL( cl_int result, const char* file, int line )
{
	if (result == CL_SUCCESS) return true;
	if (result == CL_DEVICE_NOT_FOUND) FatalError("Error: CL_DEVICE_NOT_FOUND\n%s, line %i", file, line, "OpenCL error");
	if (result == CL_DEVICE_NOT_AVAILABLE) FatalError("Error: CL_DEVICE_NOT_AVAILABLE\n%s, line %i", file, line, "OpenCL error");
	if (result == CL_COMPILER_NOT_AVAILABLE) FatalError("Error: CL_COMPILER_NOT_AVAILABLE\n%s, line %i", file, line, "OpenCL error");
	if (result == CL_MEM_OBJECT_ALLOCATION_FAILURE) FatalError("Error: CL_MEM_OBJECT_ALLOCATION_FAILURE\n%s, line %i", file, line, "OpenCL error");
	if (result == CL_OUT_OF_RESOURCES) FatalError("Error: CL_OUT_OF_RESOURCES\n%s, line %i", file, line, "OpenCL error");
	if (result == CL_OUT_OF_HOST_MEMORY) FatalError("Error: CL_OUT_OF_HOST_MEMORY\n%s, line %i", file, line, "OpenCL error");
	if (result == CL_PROFILING_INFO_NOT_AVAILABLE) FatalError("Error: CL_PROFILING_INFO_NOT_AVAILABLE\n%s, line %i", file, line, "OpenCL error");
	if (result == CL_MEM_COPY_OVERLAP) FatalError("Error: CL_MEM_COPY_OVERLAP\n%s, line %i", file, line, "OpenCL error");
	if (result == CL_IMAGE_FORMAT_MISMATCH) FatalError("Error: CL_IMAGE_FORMAT_MISMATCH\n%s, line %i", file, line, "OpenCL error");
	if (result == CL_IMAGE_FORMAT_NOT_SUPPORTED) FatalError("Error: CL_IMAGE_FORMAT_NOT_SUPPORTED\n%s, line %i", file, line, "OpenCL error");
	if (result == CL_BUILD_PROGRAM_FAILURE) FatalError("Error: CL_BUILD_PROGRAM_FAILURE\n%s, line %i", file, line, "OpenCL error");
	if (result == CL_MAP_FAILURE) FatalError("Error: CL_MAP_FAILURE\n%s, line %i", file, line, "OpenCL error");
	if (result == CL_MISALIGNED_SUB_BUFFER_OFFSET) FatalError("Error: CL_MISALIGNED_SUB_BUFFER_OFFSET\n%s, line %i", file, line, "OpenCL error");
	if (result == CL_EXEC_STATUS_ERROR_FOR_EVENTS_IN_WAIT_LIST) FatalError("Error: CL_EXEC_STATUS_ERROR_FOR_EVENTS_IN_WAIT_LIST\n%s, line %i", file, line, "OpenCL error");
	if (result == CL_INVALID_VALUE) FatalError("Error: CL_INVALID_VALUE\n%s, line %i", file, line, "OpenCL error");
	if (result == CL_INVALID_DEVICE_TYPE) FatalError("Error: CL_INVALID_DEVICE_TYPE\n%s, line %i", file, line, "OpenCL error");
	if (result == CL_INVALID_PLATFORM) FatalError("Error: CL_INVALID_PLATFORM\n%s, line %i", file, line, "OpenCL error");
	if (result == CL_INVALID_DEVICE) FatalError("Error: CL_INVALID_DEVICE\n%s, line %i", file, line, "OpenCL error");
	if (result == CL_INVALID_CONTEXT) FatalError("Error: CL_INVALID_CONTEXT\n%s, line %i", file, line, "OpenCL error");
	if (result == CL_INVALID_QUEUE_PROPERTIES) FatalError("Error: CL_INVALID_QUEUE_PROPERTIES\n%s, line %i", file, line, "OpenCL error");
	if (result == CL_INVALID_COMMAND_QUEUE) FatalError("Error: CL_INVALID_COMMAND_QUEUE\n%s, line %i", file, line, "OpenCL error");
	if (result == CL_INVALID_HOST_PTR) FatalError("Error: CL_INVALID_HOST_PTR\n%s, line %i", file, line, "OpenCL error");
	if (result == CL_INVALID_MEM_OBJECT) FatalError("Error: CL_INVALID_MEM_OBJECT\n%s, line %i", file, line, "OpenCL error");
	if (result == CL_INVALID_IMAGE_FORMAT_DESCRIPTOR) FatalError("Error: CL_INVALID_IMAGE_FORMAT_DESCRIPTOR\n%s, line %i", file, line, "OpenCL error");
	if (result == CL_INVALID_IMAGE_SIZE) FatalError("Error: CL_INVALID_IMAGE_SIZE\n%s, line %i", file, line, "OpenCL error");
	if (result == CL_INVALID_SAMPLER) FatalError("Error: CL_INVALID_SAMPLER\n%s, line %i", file, line, "OpenCL error");
	if (result == CL_INVALID_BINARY) FatalError("Error: CL_INVALID_BINARY\n%s, line %i", file, line, "OpenCL error");
	if (result == CL_INVALID_BUILD_OPTIONS) FatalError("Error: CL_INVALID_BUILD_OPTIONS\n%s, line %i", file, line, "OpenCL error");
	if (result == CL_INVALID_PROGRAM) FatalError("Error: CL_INVALID_PROGRAM\n%s, line %i", file, line, "OpenCL error");
	if (result == CL_INVALID_PROGRAM_EXECUTABLE) FatalError("Error: CL_INVALID_PROGRAM_EXECUTABLE\n%s, line %i", file, line, "OpenCL error");
	if (result == CL_INVALID_KERNEL_NAME) FatalError("Error: CL_INVALID_KERNEL_NAME\n%s, line %i", file, line, "OpenCL error");
	if (result == CL_INVALID_KERNEL_DEFINITION) FatalError("Error: CL_INVALID_KERNEL_DEFINITION\n%s, line %i", file, line, "OpenCL error");
	if (result == CL_INVALID_KERNEL) FatalError("Error: CL_INVALID_KERNEL\n%s, line %i", file, line, "OpenCL error");
	if (result == CL_INVALID_ARG_INDEX) FatalError("Error: CL_INVALID_ARG_INDEX\n%s, line %i", file, line, "OpenCL error");
	if (result == CL_INVALID_ARG_VALUE) FatalError("Error: CL_INVALID_ARG_VALUE\n%s, line %i", file, line, "OpenCL error");
	if (result == CL_INVALID_ARG_SIZE) FatalError("Error: CL_INVALID_ARG_SIZE\n%s, line %i", file, line, "OpenCL error");
	if (result == CL_INVALID_KERNEL_ARGS) FatalError("Error: CL_INVALID_KERNEL_ARGS\n%s, line %i", file, line, "OpenCL error");
	if (result == CL_INVALID_WORK_DIMENSION) FatalError("Error: CL_INVALID_WORK_DIMENSION\n%s, line %i", file, line, "OpenCL error");
	if (result == CL_INVALID_WORK_GROUP_SIZE) FatalError("Error: CL_INVALID_WORK_GROUP_SIZE\n%s, line %i", file, line, "OpenCL error");
	if (result == CL_INVALID_WORK_ITEM_SIZE) FatalError("Error: CL_INVALID_WORK_ITEM_SIZE\n%s, line %i", file, line, "OpenCL error");
	if (result == CL_INVALID_GLOBAL_OFFSET) FatalError("Error: CL_INVALID_GLOBAL_OFFSET\n%s, line %i", file, line, "OpenCL error");
	if (result == CL_INVALID_EVENT_WAIT_LIST) FatalError("Error: CL_INVALID_EVENT_WAIT_LIST\n%s, line %i", file, line, "OpenCL error");
	if (result == CL_INVALID_EVENT) FatalError("Error: CL_INVALID_EVENT\n%s, line %i", file, line, "OpenCL error");
	if (result == CL_INVALID_OPERATION) FatalError("Error: CL_INVALID_OPERATION\n%s, line %i", file, line, "OpenCL error");
	if (result == CL_INVALID_GL_OBJECT) FatalError("Error: CL_INVALID_GL_OBJECT\n%s, line %i", file, line, "OpenCL error");
	if (result == CL_INVALID_BUFFER_SIZE) FatalError("Error: CL_INVALID_BUFFER_SIZE\n%s, line %i", file, line, "OpenCL error");
	if (result == CL_INVALID_MIP_LEVEL) FatalError("Error: CL_INVALID_MIP_LEVEL\n%s, line %i", file, line, "OpenCL error");
	if (result == CL_INVALID_GLOBAL_WORK_SIZE) FatalError("Error: CL_INVALID_GLOBAL_WORK_SIZE\n%s, line %i", file, line, "OpenCL error");
	if (result == CL_INVALID_PROPERTY) FatalError("Error: CL_INVALID_PROPERTY\n%s, line %i", file, line, "OpenCL error");
	if (result == CL_INVALID_IMAGE_DESCRIPTOR) FatalError("Error: CL_INVALID_IMAGE_DESCRIPTOR\n%s, line %i", file, line, "OpenCL error");
	if (result == CL_INVALID_COMPILER_OPTIONS) FatalError("Error: CL_INVALID_COMPILER_OPTIONS\n%s, line %i", file, line, "OpenCL error");
	if (result == CL_INVALID_LINKER_OPTIONS) FatalError("Error: CL_INVALID_LINKER_OPTIONS\n%s, line %i", file, line, "OpenCL error");
	if (result == CL_INVALID_DEVICE_PARTITION_COUNT) FatalError("Error: CL_INVALID_DEVICE_PARTITION_COUNT\n%s, line %i", file, line, "OpenCL error");
	if (result == CL_INVALID_PIPE_SIZE) FatalError("Error: CL_INVALID_PIPE_SIZE\n%s, line %i", file, line, "OpenCL error");
	if (result == CL_INVALID_DEVICE_QUEUE) FatalError("Error: CL_INVALID_DEVICE_QUEUE\n%s, line %i", file, line, "OpenCL error");
	return false;
}

// getFirstDevice
// ----------------------------------------------------------------------------
static cl_device_id getFirstDevice( cl_context context )
{
	size_t dataSize;
	cl_device_id* devices;
	clGetContextInfo( context, CL_CONTEXT_DEVICES, 0, NULL, &dataSize );
	devices = (cl_device_id*)malloc( dataSize );
	clGetContextInfo( context, CL_CONTEXT_DEVICES, dataSize, devices, NULL );
	cl_device_id first = devices[0];
	free( devices );
	return first;
}

// getPlatformID
// ----------------------------------------------------------------------------
static cl_int getPlatformID( cl_platform_id* platform )
{
	char chBuffer[1024];
	cl_uint num_platforms, devCount;
	cl_platform_id* clPlatformIDs;
	cl_int error;
	*platform = NULL;
	CHECKCL( error = clGetPlatformIDs( 0, NULL, &num_platforms ) );
	if (num_platforms == 0) CHECKCL( -1 );
	clPlatformIDs = (cl_platform_id*)malloc( num_platforms * sizeof( cl_platform_id ) );
	error = clGetPlatformIDs( num_platforms, clPlatformIDs, NULL );
	cl_uint deviceType[2] = { CL_DEVICE_TYPE_GPU, CL_DEVICE_TYPE_CPU };
	char* deviceOrder[2][3] = { { "NVIDIA", "AMD", "" }, { "", "", "" } };
	printf( "available OpenCL platforms:\n" );
	for (cl_uint i = 0; i < num_platforms; ++i)
	{
		CHECKCL( error = clGetPlatformInfo( clPlatformIDs[i], CL_PLATFORM_NAME, 1024, &chBuffer, NULL ) );
		printf( "#%i: %s\n", i, chBuffer );
	}
	for (cl_uint j = 0; j < 2; j++) for (int k = 0; k < 3; k++) for (cl_uint i = 0; i < num_platforms; ++i)
	{
		error = clGetDeviceIDs( clPlatformIDs[i], deviceType[j], 0, NULL, &devCount );
		if ((error != CL_SUCCESS) || (devCount == 0)) continue;
		CHECKCL( error = clGetPlatformInfo( clPlatformIDs[i], CL_PLATFORM_NAME, 1024, &chBuffer, NULL ) );
		if (deviceOrder[j][k][0]) if (!strstr( chBuffer, deviceOrder[j][k] )) continue;
		printf( "OpenCL device: %s\n", chBuffer );
		*platform = clPlatformIDs[i], j = 2, k = 3;
		break;
	}
	free( clPlatformIDs );
	return CL_SUCCESS;
}

// Buffer constructor
// ----------------------------------------------------------------------------
Buffer::Buffer(unsigned int N, void* ptr, unsigned int t)
{
	if (!Kernel::clStarted) Kernel::InitCL();
	type = t;
	ownData = false;
	int rwFlags = CL_MEM_READ_WRITE;
	if (t & READONLY) rwFlags = CL_MEM_READ_ONLY;
	if (t & WRITEONLY) rwFlags = CL_MEM_WRITE_ONLY;
	aligned = false;
	if ((t & (TEXTURE | TARGET)) == 0)
	{
		size = N;
		textureID = 0; // not representing a texture
		deviceBuffer = clCreateBuffer(Kernel::GetContext(), rwFlags, size, 0, 0);
		hostBuffer = (uint*)ptr;
	}
	else
	{
		textureID = N; // representing texture N
		if (!Kernel::candoInterop) FatalError("didn't expect to get here.");
		int error = 0;
		if (t == TARGET) deviceBuffer = clCreateFromGLTexture(Kernel::GetContext(), CL_MEM_WRITE_ONLY, GL_TEXTURE_2D, 0, N, &error);
		else deviceBuffer = clCreateFromGLTexture(Kernel::GetContext(), CL_MEM_READ_ONLY, GL_TEXTURE_2D, 0, N, &error);
		CHECKCL(error);
		hostBuffer = 0;
	}
}

// Buffer destructor
// ----------------------------------------------------------------------------
Buffer::~Buffer()
{
	if (ownData)
	{
		FREE64(hostBuffer);
		hostBuffer = 0;
	}
	if ((type & (TEXTURE | TARGET)) == 0) clReleaseMemObject(deviceBuffer);
}

// CopyToDevice method
// ----------------------------------------------------------------------------
void Buffer::CopyToDevice(bool blocking)
{
	cl_int error;
	CHECKCL(error = clEnqueueWriteBuffer(Kernel::GetQueue(), deviceBuffer, blocking, 0, size, hostBuffer, 0, 0, 0));
}

// CopyToDevice2 method (uses 2nd queue)
// ----------------------------------------------------------------------------
void Buffer::CopyToDevice2(bool blocking, cl_event* eventToSet, const size_t s)
{
	cl_int error;
	CHECKCL(error = clEnqueueWriteBuffer(Kernel::GetQueue2(), deviceBuffer, blocking ? CL_TRUE : CL_FALSE, 0, s == 0 ? size : s, hostBuffer, 0, 0, eventToSet));
}

// CopyFromDevice method
// ----------------------------------------------------------------------------
void Buffer::CopyFromDevice(bool blocking)
{
	cl_int error;
	if (!hostBuffer)
	{
		hostBuffer = (uint*)MALLOC64(size);
		ownData = true;
		aligned = true;
	}
	CHECKCL(error = clEnqueueReadBuffer(Kernel::GetQueue(), deviceBuffer, blocking, 0, size, hostBuffer, 0, 0, 0));
}

// CopyTo
// ----------------------------------------------------------------------------
void Buffer::CopyTo(Buffer* buffer)
{
	clEnqueueCopyBuffer(Kernel::GetQueue(), deviceBuffer, buffer->deviceBuffer, 0, 0, size, 0, 0, 0);
}

// Clear
// ----------------------------------------------------------------------------
void Buffer::Clear()
{
	uint value = 0;
#if 0
	memset(hostBuffer, 0, size);
	CopyToDevice();
#else
	cl_int error;
	CHECKCL(error = clEnqueueFillBuffer(Kernel::GetQueue(), deviceBuffer, &value, 4, 0, size, 0, 0, 0));
#endif
}

// Kernel constructor
// ----------------------------------------------------------------------------
Kernel::Kernel(char* file, char* entryPoint)
{
	if (!clStarted) InitCL();
	// load a cl file
	string csText = TextFileRead(file);
	if (csText.size() == 0) FatalError("File %s not found", file);
	// add vendor defines
	vendorLines = 0;
	if (isNVidia) csText = "#define ISNVIDIA\n" + csText, vendorLines++;
	if (isAMD) csText = "#define ISAMD\n" + csText, vendorLines++;
	if (isIntel) csText = "#define ISINTEL\n" + csText, vendorLines++;
	if (isOther) csText = "#define ISOTHER\n" + csText, vendorLines++;
	if (isAmpere) csText = "#define ISAMPERE\n" + csText, vendorLines++;
	if (isTuring) csText = "#define ISTURING\n" + csText, vendorLines++;
	if (isPascal) csText = "#define ISPASCAL\n" + csText, vendorLines++;
	// expand #include directives: cl compiler doesn't support these natively
	// warning: this simple system does not handle nested includes.
	struct Include { int start, end; string file; } includes[64];
	int Ninc = 0;
#if 0 // needed for NVIDIA OpenCL 1.0; this no longer is necessary
	while (1)
	{
		// see if any #includes remain
		size_t pos = csText.find("#include");
		if (pos == string::npos) break;
		// start of expanded source construction
		string tmp;
		if (pos > 0)
			tmp = csText.substr(0, pos - 1) + "\n",
			includes[Ninc].start = LineCount(tmp); // record first line of #include content
		else
			includes[Ninc].start = 0;
		// parse filename of include file
		pos = csText.find("\"", pos + 1);
		if (pos == string::npos) FatalError("Expected \" after #include in shader.");
		size_t end = csText.find("\"", pos + 1);
		if (end == string::npos) FatalError("Expected second \" after #include in shader.");
		string file = csText.substr(pos + 1, end - pos - 1);
		// load include file content
		string incText = TextFileRead(file.c_str());
		includes[Ninc].end = includes[Ninc].start + LineCount(incText);
		includes[Ninc++].file = file;
		if (incText.size() == 0) FatalError("#include file not found:\n%s", file.c_str());
		// cleanup include file content: we get some crap first sometimes, but why?
		int firstValidChar = 0;
		while (incText[firstValidChar] < 0) firstValidChar++;
		// add include file content and remainder of source to expanded source string
		tmp += incText.substr(firstValidChar, string::npos);
		tmp += csText.substr(end + 1, string::npos) + "\n";
		// repeat until no #includes left
		csText = tmp;
	}
#endif
	// attempt to compile the loaded and expanded source text
	const char* source = csText.c_str();
	size_t size = strlen(source);
	cl_int error;
	program = clCreateProgramWithSource(context, 1, (const char**)&source, &size, &error);
	CHECKCL(error);
	// why does the nvidia compiler not support these:
	// -cl-nv-maxrregcount=64 not faster than leaving it out (same for 128)
	// -cl-no-subgroup-ifp ? fails on nvidia.
#if 1
	// AMD compatible compilation, thanks Jasper the Winther
	error = clBuildProgram(program, 0, NULL, "-cl-fast-relaxed-math -cl-mad-enable -cl-single-precision-constant", NULL, NULL);

#else
	error = clBuildProgram(program, 0, NULL, "-cl-nv-verbose -cl-fast-relaxed-math -cl-mad-enable -cl-single-precision-constant", NULL, NULL);
#endif
	// handle errors
	if (error == CL_SUCCESS)
	{
		// dump PTX via: https://forums.developer.nvidia.com/t/pre-compiling-opencl-kernels-tutorial/17089
		// and: https://stackoverflow.com/questions/12868889/clgetprograminfo-cl-program-binary-sizes-incorrect-results
		cl_uint devCount;
		CHECKCL(clGetProgramInfo(program, CL_PROGRAM_NUM_DEVICES, sizeof(cl_uint), &devCount, NULL));
		size_t* size = new size_t[devCount];
		size[0] = 0;
		size_t received;
		CHECKCL(clGetProgramInfo(program, CL_PROGRAM_BINARY_SIZES /* wrong data... */, devCount * sizeof(size_t), size, &received));
		char** binaries = new char* [devCount];
		for (uint i = 0; i < devCount; i++)
			binaries[i] = new char[size[i] + 1];
		CHECKCL(clGetProgramInfo(program, CL_PROGRAM_BINARIES, devCount * sizeof(size_t), binaries, NULL));
		FILE* f = fopen("buildlog.txt", "wb");
		for (uint i = 0; i < devCount; i++)
			fwrite(binaries[i], 1, size[i] + 1, f);
		fclose(f);
	}
	else
	{
		// obtain the error log from the cl compiler
		if (!log) log = new char[256 * 1024]; // can be quite large
		log[0] = 0;
		clGetProgramBuildInfo(program, getFirstDevice(context), CL_PROGRAM_BUILD_LOG, 256 * 1024, log, &size);
		// save error log for closer inspection
		FILE* f = fopen("errorlog.txt", "wb");
		fwrite(log, 1, size, f);
		fclose(f);
		// find and display the first error. Note: platform specific sadly; code below is for NVIDIA
		char* error = strstr(log, ": error:");
		if (error)
		{
			int errorPos = (int)(error - log);
			while (errorPos > 0) if (log[errorPos - 1] == '\n') break; else errorPos--;
			// translate file and line number of error and report
			log[errorPos + 2048] = 0;
			int lineNr = 0, linePos = 0;
			char* lns = strstr(log + errorPos, ">:"), * eol;
			if (!lns) FatalError(log + errorPos); else
			{
				lns += 2;
				while (*lns >= '0' && *lns <= '9') lineNr = lineNr * 10 + (*lns++ - '0');
				lns++; // proceed to line number
				while (*lns >= '0' && *lns <= '9') linePos = linePos * 10 + (*lns++ - '0');
				lns += 9; // proceed to error message
				eol = lns;
				while (*eol != '\n' && *eol > 0) eol++;
				*eol = 0;
				lineNr--; // we count from 0 instead of 1
				// adjust file and linenr based on include file data
				string errorFile = file;
				bool errorInInclude = false;
				for (int i = Ninc - 1; i >= 0; i--)
				{
					if (lineNr > includes[i].end)
					{
						for (int j = 0; j <= i; j++) lineNr -= includes[j].end - includes[j].start;
						break;
					}
					else if (lineNr > includes[i].start)
					{
						errorFile = includes[i].file;
						lineNr -= includes[i].start;
						errorInInclude = true;
						break;
					}
				}
				if (!errorInInclude) lineNr -= vendorLines;
				// present error message
				char t[1024];
				sprintf(t, "file %s, line %i, pos %i:\n%s", errorFile.c_str(), lineNr + 1, linePos, lns);
				FatalError(t, "Build error");
			}
		}
		else
		{
			// error string has unknown format; just dump it to a window
			log[2048] = 0; // truncate very long logs
			FatalError(log, "Build error");
		}
	}
	kernel = clCreateKernel(program, entryPoint, &error);
	if (kernel == 0) FatalError("clCreateKernel failed: entry point not found.");
	CHECKCL(error);
}

Kernel::Kernel(cl_program& existingProgram, char* entryPoint)
{
	CheckCLStarted();
	cl_int error;
	program = existingProgram;
	kernel = clCreateKernel(program, entryPoint, &error);
	if (kernel == 0) FatalError("clCreateKernel failed: entry point not found.");
	CHECKCL(error);
}

// Kernel destructor
// ----------------------------------------------------------------------------
Kernel::~Kernel()
{
	if (kernel) clReleaseKernel(kernel);
	// if (program) clReleaseProgram( program ); // NOTE: may be shared with other kernels
	kernel = 0;
	// program = 0;
}

// InitCL method
// ----------------------------------------------------------------------------
bool Kernel::InitCL()
{
	cl_platform_id platform;
	cl_device_id* devices;
	cl_uint devCount;
	cl_int error;
	if (!CHECKCL(error = getPlatformID(&platform))) return false;
	if (!CHECKCL(error = clGetDeviceIDs(platform, CL_DEVICE_TYPE_ALL, 0, NULL, &devCount))) return false;
	devices = new cl_device_id[devCount];
	if (!CHECKCL(error = clGetDeviceIDs(platform, CL_DEVICE_TYPE_ALL, devCount, devices, NULL))) return false;
	uint deviceUsed = -1;
	// search a capable OpenCL device
	char device_string[1024], device_platform[1024];
	for (uint i = 0; i < devCount; i++)
	{
		// CHECKCL( error = clGetDeviceInfo( devices[i], CL_DEVICE_NAME, 1024, &device_string, NULL ) );
		// if (strstr( device_string, "AMD" ) == 0) continue; // I insist on AMD
		size_t extensionSize;
		CHECKCL(error = clGetDeviceInfo(devices[i], CL_DEVICE_EXTENSIONS, 0, NULL, &extensionSize));
		if (extensionSize > 0)
		{
			char* extensions = (char*)malloc(extensionSize);
			CHECKCL(error = clGetDeviceInfo(devices[i], CL_DEVICE_EXTENSIONS, extensionSize, extensions, &extensionSize));
			string deviceList(extensions);
			free(extensions);
			string mustHave[] = {
				"cl_khr_gl_sharing",
				"cl_khr_global_int32_base_atomics"
			};
			bool hasAll = true;
			for (int j = 0; j < 2; j++)
			{
				size_t o = 0, s = deviceList.find(' ', o);
				bool hasFeature = false;
				while (s != deviceList.npos)
				{
					string subs = deviceList.substr(o, s - o);
					if (strcmp(mustHave[j].c_str(), subs.c_str()) == 0) hasFeature = true;
					do { o = s + 1, s = deviceList.find(' ', o); } while (s == o);
				}
				if (!hasFeature) hasAll = false;
			}
			if (hasAll)
			{
				cl_context_properties props[] =
				{
					// CL_GL_CONTEXT_KHR, (cl_context_properties)glfwGetWGLContext(window),
					CL_WGL_HDC_KHR, (cl_context_properties)wglGetCurrentDC(),
					CL_CONTEXT_PLATFORM, (cl_context_properties)platform, 0
				};
				// attempt to create a context with the requested features
				context = clCreateContext(props, 1, &devices[i], NULL, NULL, &error);
				if (error == CL_SUCCESS)
				{
					candoInterop = true;
					deviceUsed = i;
					break;
				}
			}
			if (deviceUsed > -1) break;
		}
	}
	if (deviceUsed == -1) FatalError("No capable OpenCL device found.");
	device = getFirstDevice(context);
	if (!CHECKCL(error)) return false;
	// print device name
	clGetDeviceInfo(devices[deviceUsed], CL_DEVICE_NAME, 1024, &device_string, NULL);
	clGetDeviceInfo(devices[deviceUsed], CL_DEVICE_VERSION, 1024, &device_platform, NULL);
	printf("Device # %u, %s (%s)\n", deviceUsed, device_string, device_platform);
	// digest device string
	char* d = device_string;
	for (int i = 0; i < strlen(d); i++) if (d[i] >= 'A' && d[i] <= 'Z') d[i] -= 'A' - 'a';
	if (strstr(d, "nvidia"))
	{
		isNVidia = true;
		if (strstr(d, "rtx"))
		{
			// detect Ampere GPUs
			if (strstr(d, "3050") || strstr(d, "3060") || strstr(d, "3070") || strstr(d, "3080") || strstr(d, "3090")) isAmpere = true;
			if (strstr(d, "a2000") || strstr(d, "a3000") || strstr(d, "a4000") || strstr(d, "a5000") || strstr(d, "a6000")) isAmpere = true;
			// detect Turing GPUs
			if (strstr(d, "2060") || strstr(d, "2070") || strstr(d, "2080")) isTuring = true;
			// detect Titan RTX
			if (strstr(d, "titan rtx")) isTuring = true;
			// detect Turing Quadro
			if (strstr(d, "quadro"))
			{
				if (strstr(d, "3000") || strstr(d, "4000") || strstr(d, "5000") || strstr(d, "6000") || strstr(d, "8000")) isTuring = true;
			}
		}
		else if (strstr(d, "gtx"))
		{
			// detect Turing GPUs
			if (strstr(d, "1650") || strstr(d, "1660")) isTuring = true;
			// detect Pascal GPUs
			if (strstr(d, "1010") || strstr(d, "1030") || strstr(d, "1050") || strstr(d, "1060") || strstr(d, "1070") || strstr(d, "1080")) isPascal = true;
		}
		else if (strstr(d, "quadro"))
		{
			// detect Pascal GPUs
			if (strstr(d, "p2000") || strstr(d, "p1000") || strstr(d, "p600") || strstr(d, "p400") || strstr(d, "p5000") || strstr(d, "p100")) isPascal = true;
		}
		else
		{
			// detect Pascal GPUs
			if (strstr(d, "titan x")) isPascal = true;
		}
	}
	else if (strstr(d, "amd") || strstr(d, "ellesmere")) // JdW
	{
		isAMD = true;
	}
	else if (strstr(d, "intel"))
	{
		isIntel = true;
	}
	else
	{
		isOther = true;
	}
	// report on findings
	printf("hardware detected: ");
	if (isNVidia)
	{
		printf("NVIDIA, ");
		if (isAmpere) printf("AMPERE class.\n");
		else if (isTuring) printf("TURING class.\n");
		else if (isPascal) printf("PASCAL class.\n");
		else printf("PRE-PASCAL hardware (warning: slow).\n");
	}
	else if (isAMD)
	{
		printf("AMD.\n");
	}
	else if (isIntel)
	{
		printf("Intel.\n");
	}
	else
	{
		printf("identification failed.\n");
	}
	// create a command-queue
	queue = clCreateCommandQueue(context, devices[deviceUsed], CL_QUEUE_PROFILING_ENABLE, &error);
	if (!CHECKCL(error)) return false;
	// create a second command queue for asynchronous copies
	queue2 = clCreateCommandQueue(context, devices[deviceUsed], CL_QUEUE_PROFILING_ENABLE, &error);
	if (!CHECKCL(error)) return false;
	// cleanup
	delete devices;
	clStarted = true;
	return true;
}

// KillCL method
// ----------------------------------------------------------------------------
void Kernel::KillCL()
{
	if (!clStarted) return;
	clReleaseCommandQueue(queue2);
	clReleaseCommandQueue(queue);
	clReleaseContext(context);
}

// CheckCLStarted method
// ----------------------------------------------------------------------------
void Kernel::CheckCLStarted()
{
	if (!clStarted) FatalError("Call InitCL() before using OpenCL functionality.");
}

// SetArgument methods
// ----------------------------------------------------------------------------
void Kernel::SetArgument(int idx, cl_mem* buffer) { CheckCLStarted(); clSetKernelArg(kernel, idx, sizeof(cl_mem), buffer); }
void Kernel::SetArgument(int idx, Buffer* buffer)
{
	CheckCLStarted();
	clSetKernelArg(kernel, idx, sizeof(cl_mem), buffer->GetDevicePtr());
	if (buffer->type & Buffer::TARGET)
	{
		if (acqBuffer) FatalError("Kernel can take only one texture target buffer argument.");
		acqBuffer = buffer;
	}
}
void Kernel::SetArgument(int idx, Buffer& buffer) { SetArgument(idx, &buffer); }
void Kernel::SetArgument(int idx, int value) { CheckCLStarted(); clSetKernelArg(kernel, idx, sizeof(int), &value); }
void Kernel::SetArgument(int idx, float value) { CheckCLStarted(); clSetKernelArg(kernel, idx, sizeof(float), &value); }
void Kernel::SetArgument(int idx, float2 value) { CheckCLStarted(); clSetKernelArg(kernel, idx, sizeof(float2), &value); }
void Kernel::SetArgument(int idx, float3 value) { CheckCLStarted(); float4 tmp(value, 0); clSetKernelArg(kernel, idx, sizeof(float4), &tmp); }
void Kernel::SetArgument(int idx, float4 value) { CheckCLStarted(); clSetKernelArg(kernel, idx, sizeof(float4), &value); }

// Run method
// ----------------------------------------------------------------------------
void Kernel::Run(const size_t count, const size_t localSize, cl_event* eventToWaitFor, cl_event* eventToSet)
{
	CheckCLStarted();
	cl_int error;
	if (acqBuffer)
	{
		if (!Kernel::candoInterop) FatalError("OpenGL interop functionality required but not available.");
		CHECKCL(error = clEnqueueAcquireGLObjects(queue, 1, acqBuffer->GetDevicePtr(), 0, 0, 0));
		CHECKCL(error = clEnqueueNDRangeKernel(queue, kernel, 1, 0, &count, localSize == 0 ? 0 : &localSize, eventToWaitFor ? 1 : 0, eventToWaitFor, eventToSet));
		CHECKCL(error = clEnqueueReleaseGLObjects(queue, 1, acqBuffer->GetDevicePtr(), 0, 0, 0));
	}
	else
	{
		CHECKCL(error = clEnqueueNDRangeKernel(queue, kernel, 1, 0, &count, localSize == 0 ? 0 : &localSize, eventToWaitFor ? 1 : 0, eventToWaitFor, eventToSet));
	}
}

void Kernel::Run2D(const int2 count, const int2 lsize, cl_event* eventToWaitFor, cl_event* eventToSet)
{
	CheckCLStarted();
	size_t workSize[2] = { (size_t)count.x, (size_t)count.y };
	size_t localSize[2];
	if (lsize.x > 0 && lsize.y > 0)
	{
		// use specified workgroup size
		localSize[0] = (size_t)lsize.x;
		localSize[1] = (size_t)lsize.y;
	}
	else
	{
		// workgroup size not specified; use something reasonable
		localSize[0] = 32;
		localSize[1] = 4;
	}
	cl_int error;
	if (acqBuffer)
	{
		if (!Kernel::candoInterop) FatalError("OpenGL interop functionality required but not available.");
		CHECKCL(error = clEnqueueAcquireGLObjects(queue, 1, acqBuffer->GetDevicePtr(), 0, 0, 0));
		CHECKCL(error = clEnqueueNDRangeKernel(queue, kernel, 2, 0, workSize, localSize, eventToWaitFor ? 1 : 0, eventToWaitFor, eventToSet));
		CHECKCL(error = clEnqueueReleaseGLObjects(queue, 1, acqBuffer->GetDevicePtr(), 0, 0, 0));
	}
	else
	{
		CHECKCL(error = clEnqueueNDRangeKernel(queue, kernel, 2, 0, workSize, localSize, eventToWaitFor ? 1 : 0, eventToWaitFor, eventToSet));
	}
}

// surface implementation
// ----------------------------------------------------------------------------

static char s_Font[51][5][6];
static bool fontInitialized = false;
static int s_Transl[256];

Surface::Surface(int w, int h, uint* b) : pixels(b), width(w), height(h) {}
Surface::Surface(int w, int h) : width(w), height(h)
{
	pixels = (uint*)MALLOC64(w * h * sizeof(uint));
	ownBuffer = true; // needs to be deleted in destructor
}
Surface::Surface(const char* file) : pixels(0), width(0), height(0)
{
	FILE* f = fopen(file, "rb");
	if (!f) FatalError("File not found: %s", file);
	fclose(f);
	LoadImage(file);
}

void Surface::LoadImage(const char* file)
{
	int n;
	unsigned char* data = stbi_load(file, &width, &height, &n, 0);
	if (data)
	{
		pixels = (uint*)MALLOC64(width * height * sizeof(uint));
		ownBuffer = true; // needs to be deleted in destructor
		const int s = width * height;
		if (n == 1) // greyscale
		{
			for (int i = 0; i < s; i++)
			{
				const unsigned char p = data[i];
				pixels[i] = p + (p << 8) + (p << 16);
			}
		}
		else
		{
			for (int i = 0; i < s; i++) pixels[i] = (data[i * n + 0] << 16) + (data[i * n + 1] << 8) + data[i * n + 2];
		}
	}
	stbi_image_free(data);
}

Surface::~Surface()
{
	if (ownBuffer) FREE64(pixels); // free only if we allocated the buffer ourselves
}

void Surface::Clear(uint c)
{
	const int s = width * height;
	for (int i = 0; i < s; i++) pixels[i] = c;
}

void Surface::Plot( int x, int y, uint c )
{
	if (x < 0 || y < 0 || x >= width || y >= height) return;
	pixels[x + y * width] = c;
}

void Surface::Box(int x1, int y1, int x2, int y2, uint c)
{
	Line((float)x1, (float)y1, (float)x2, (float)y1, c);
	Line((float)x2, (float)y1, (float)x2, (float)y2, c);
	Line((float)x1, (float)y2, (float)x2, (float)y2, c);
	Line((float)x1, (float)y1, (float)x1, (float)y2, c);
}

void Surface::Bar(int x1, int y1, int x2, int y2, uint c)
{
	// clipping
	if (x1 < 0) x1 = 0;
	if (x2 >= width) x2 = width - 1;
	if (y1 < 0) y1 = 0;
	if (y2 >= height) y2 = width - 1;
	// draw clipped bar
	uint* a = x1 + y1 * width + pixels;
	for (int y = y1; y <= y2; y++)
	{
		for (int x = 0; x <= (x2 - x1); x++) a[x] = c;
		a += width;
	}
}

void Surface::Print(const char* s, int x1, int y1, uint c)
{
	if (!fontInitialized)
	{
		InitCharset();
		fontInitialized = true;
	}
	uint* t = pixels + x1 + y1 * width;
	for (int i = 0; i < (int)(strlen(s)); i++, t += 6)
	{
		int pos = 0;
		if ((s[i] >= 'A') && (s[i] <= 'Z')) pos = s_Transl[(unsigned short)(s[i] - ('A' - 'a'))];
		else pos = s_Transl[(unsigned short)s[i]];
		uint* a = t;
		const char* u = (const char*)s_Font[pos];
		for (int v = 0; v < 5; v++, u++, a += width)
			for (int h = 0; h < 5; h++) if (*u++ == 'o') *(a + h) = c, * (a + h + width) = 0;
	}
}

#define OUTCODE(x,y) (((x)<xmin)?1:(((x)>xmax)?2:0))+(((y)<ymin)?4:(((y)>ymax)?8:0))

void Surface::Line(float x1, float y1, float x2, float y2, uint c)
{
	// clip (Cohen-Sutherland, https://en.wikipedia.org/wiki/Cohen%E2%80%93Sutherland_algorithm)
	const float xmin = 0, ymin = 0, xmax = (float)width - 1, ymax = (float)height - 1;
	int c0 = OUTCODE(x1, y1), c1 = OUTCODE(x2, y2);
	bool accept = false;
	while (1)
	{
		if (!(c0 | c1)) { accept = true; break; }
		else if (c0 & c1) break; else
		{
			float x, y;
			const int co = c0 ? c0 : c1;
			if (co & 8) x = x1 + (x2 - x1) * (ymax - y1) / (y2 - y1), y = ymax;
			else if (co & 4) x = x1 + (x2 - x1) * (ymin - y1) / (y2 - y1), y = ymin;
			else if (co & 2) y = y1 + (y2 - y1) * (xmax - x1) / (x2 - x1), x = xmax;
			else if (co & 1) y = y1 + (y2 - y1) * (xmin - x1) / (x2 - x1), x = xmin;
			if (co == c0) x1 = x, y1 = y, c0 = OUTCODE( x1, y1 );
			else x2 = x, y2 = y, c1 = OUTCODE( x2, y2 );
		}
	}
	if (!accept) return;
	float b = x2 - x1;
	float h = y2 - y1;
	float l = fabsf( b );
	if (fabsf( h ) > l) l = fabsf( h );
	int il = (int)l;
	float dx = b / (float)l;
	float dy = h / (float)l;
	for (int i = 0; i <= il; i++)
	{
		*(pixels + (int)x1 + (int)y1 * width) = c;
		x1 += dx, y1 += dy;
	}
}

void Surface::CopyTo( Surface* d, int x, int y )
{
	uint* dst = d->pixels;
	uint* src = pixels;
	if ((src) && (dst))
	{
		int srcwidth = width;
		int srcheight = height;
		int dstwidth = d->width;
		int dstheight = d->height;
		if ((srcwidth + x) > dstwidth) srcwidth = dstwidth - x;
		if ((srcheight + y) > dstheight) srcheight = dstheight - y;
		if (x < 0) src -= x, srcwidth += x, x = 0;
		if (y < 0) src -= y * srcwidth, srcheight += y, y = 0;
		if ((srcwidth > 0) && (srcheight > 0))
		{
			dst += x + dstwidth * y;
			for (int y = 0; y < srcheight; y++)
			{
				memcpy( dst, src, srcwidth * 4 );
				dst += dstwidth, src += srcwidth;
			}
		}
	}
}

void Surface::SetChar( int c, const char* c1, const char* c2, const char* c3, const char* c4, const char* c5 )
{
	strcpy( s_Font[c][0], c1 );
	strcpy( s_Font[c][1], c2 );
	strcpy( s_Font[c][2], c3 );
	strcpy( s_Font[c][3], c4 );
	strcpy( s_Font[c][4], c5 );
}

void Surface::InitCharset()
{
	SetChar( 0, ":ooo:", "o:::o", "ooooo", "o:::o", "o:::o" );
	SetChar( 1, "oooo:", "o:::o", "oooo:", "o:::o", "oooo:" );
	SetChar( 2, ":oooo", "o::::", "o::::", "o::::", ":oooo" );
	SetChar( 3, "oooo:", "o:::o", "o:::o", "o:::o", "oooo:" );
	SetChar( 4, "ooooo", "o::::", "oooo:", "o::::", "ooooo" );
	SetChar( 5, "ooooo", "o::::", "ooo::", "o::::", "o::::" );
	SetChar( 6, ":oooo", "o::::", "o:ooo", "o:::o", ":ooo:" );
	SetChar( 7, "o:::o", "o:::o", "ooooo", "o:::o", "o:::o" );
	SetChar( 8, "::o::", "::o::", "::o::", "::o::", "::o::" );
	SetChar( 9, ":::o:", ":::o:", ":::o:", ":::o:", "ooo::" );
	SetChar( 10, "o::o:", "o:o::", "oo:::", "o:o::", "o::o:" );
	SetChar( 11, "o::::", "o::::", "o::::", "o::::", "ooooo" );
	SetChar( 12, "oo:o:", "o:o:o", "o:o:o", "o:::o", "o:::o" );
	SetChar( 13, "o:::o", "oo::o", "o:o:o", "o::oo", "o:::o" );
	SetChar( 14, ":ooo:", "o:::o", "o:::o", "o:::o", ":ooo:" );
	SetChar( 15, "oooo:", "o:::o", "oooo:", "o::::", "o::::" );
	SetChar( 16, ":ooo:", "o:::o", "o:::o", "o::oo", ":oooo" );
	SetChar( 17, "oooo:", "o:::o", "oooo:", "o:o::", "o::o:" );
	SetChar( 18, ":oooo", "o::::", ":ooo:", "::::o", "oooo:" );
	SetChar( 19, "ooooo", "::o::", "::o::", "::o::", "::o::" );
	SetChar( 20, "o:::o", "o:::o", "o:::o", "o:::o", ":oooo" );
	SetChar( 21, "o:::o", "o:::o", ":o:o:", ":o:o:", "::o::" );
	SetChar( 22, "o:::o", "o:::o", "o:o:o", "o:o:o", ":o:o:" );
	SetChar( 23, "o:::o", ":o:o:", "::o::", ":o:o:", "o:::o" );
	SetChar( 24, "o:::o", "o:::o", ":oooo", "::::o", ":ooo:" );
	SetChar( 25, "ooooo", ":::o:", "::o::", ":o:::", "ooooo" );
	SetChar( 26, ":ooo:", "o::oo", "o:o:o", "oo::o", ":ooo:" );
	SetChar( 27, "::o::", ":oo::", "::o::", "::o::", ":ooo:" );
	SetChar( 28, ":ooo:", "o:::o", "::oo:", ":o:::", "ooooo" );
	SetChar( 29, "oooo:", "::::o", "::oo:", "::::o", "oooo:" );
	SetChar( 30, "o::::", "o::o:", "ooooo", ":::o:", ":::o:" );
	SetChar( 31, "ooooo", "o::::", "oooo:", "::::o", "oooo:" );
	SetChar( 32, ":oooo", "o::::", "oooo:", "o:::o", ":ooo:" );
	SetChar( 33, "ooooo", "::::o", ":::o:", "::o::", "::o::" );
	SetChar( 34, ":ooo:", "o:::o", ":ooo:", "o:::o", ":ooo:" );
	SetChar( 35, ":ooo:", "o:::o", ":oooo", "::::o", ":ooo:" );
	SetChar( 36, "::o::", "::o::", "::o::", ":::::", "::o::" );
	SetChar( 37, ":ooo:", "::::o", ":::o:", ":::::", "::o::" );
	SetChar( 38, ":::::", ":::::", "::o::", ":::::", "::o::" );
	SetChar( 39, ":::::", ":::::", ":ooo:", ":::::", ":ooo:" );
	SetChar( 40, ":::::", ":::::", ":::::", ":::o:", "::o::" );
	SetChar( 41, ":::::", ":::::", ":::::", ":::::", "::o::" );
	SetChar( 42, ":::::", ":::::", ":ooo:", ":::::", ":::::" );
	SetChar( 43, ":::o:", "::o::", "::o::", "::o::", ":::o:" );
	SetChar( 44, "::o::", ":::o:", ":::o:", ":::o:", "::o::" );
	SetChar( 45, ":::::", ":::::", ":::::", ":::::", ":::::" );
	SetChar( 46, "ooooo", "ooooo", "ooooo", "ooooo", "ooooo" );
	SetChar( 47, "::o::", "::o::", ":::::", ":::::", ":::::" ); // Tnx Ferry
	SetChar( 48, "o:o:o", ":ooo:", "ooooo", ":ooo:", "o:o:o" );
	SetChar( 49, "::::o", ":::o:", "::o::", ":o:::", "o::::" );
	char c[] = "abcdefghijklmnopqrstuvwxyz0123456789!?:=,.-() #'*/";
	int i;
	for (i = 0; i < 256; i++) s_Transl[i] = 45;
	for (i = 0; i < 50; i++) s_Transl[(unsigned char)c[i]] = i;
}

Sprite::Sprite(Surface* a_Surface, unsigned int a_NumFrames) :
	width(a_Surface->width / a_NumFrames),
	height(a_Surface->height),
	numFrames(a_NumFrames),
	currentFrame(0),
	flags(0),
	start(new unsigned int* [a_NumFrames]),
	surface(a_Surface)
{
	InitializeStartData();
}

Sprite::~Sprite()
{
	delete surface;
	for (unsigned int i = 0; i < numFrames; i++) delete start[i];
	delete start;
}

void Sprite::Draw(Surface* a_Target, int a_X, int a_Y)
{
	if ((a_X < -width) || (a_X > (a_Target->width + width))) return;
	if ((a_Y < -height) || (a_Y > (a_Target->height + height))) return;
	int x1 = a_X, x2 = a_X + width;
	int y1 = a_Y, y2 = a_Y + height;
	uint* src = GetBuffer() + currentFrame * width;
	if (x1 < 0) src += -x1, x1 = 0;
	if (x2 > a_Target->width) x2 = a_Target->width;
	if (y1 < 0) src += -y1 * width * numFrames, y1 = 0;
	if (y2 > a_Target->height) y2 = a_Target->height;
	uint* dest = a_Target->pixels;
	int xs;
	const int dpitch = a_Target->width;
	if ((x2 > x1) && (y2 > y1))
	{
		unsigned int addr = y1 * dpitch + x1;
		const int w = x2 - x1;
		const int h = y2 - y1;
		for (int y = 0; y < h; y++)
		{
			const int line = y + (y1 - a_Y);
			const int lsx = start[currentFrame][line] + a_X;
			xs = (lsx > x1) ? lsx - x1 : 0;
			for (int x = xs; x < w; x++)
			{
				const uint c1 = *(src + x);
				if (c1 & 0xffffff) *(dest + addr + x) = c1;
			}
			addr += dpitch;
			src += width * numFrames;
		}
	}
}

void Sprite::DrawScaled(int a_X, int a_Y, int a_Width, int a_Height, Surface* a_Target)
{
	if ((a_Width == 0) || (a_Height == 0)) return;
	for (int x = 0; x < a_Width; x++) for (int y = 0; y < a_Height; y++)
	{
		int u = (int)((float)x * ((float)width / (float)a_Width));
		int v = (int)((float)y * ((float)height / (float)a_Height));
		uint color = GetBuffer()[u + v * width * numFrames];
		if (color & 0xffffff) a_Target->pixels[a_X + x + ((a_Y + y) * a_Target->width)] = color;
	}
}

void Sprite::InitializeStartData()
{
	for (unsigned int f = 0; f < numFrames; ++f)
	{
		start[f] = new unsigned int[height];
		for (int y = 0; y < height; ++y)
		{
			start[f][y] = width;
			uint* addr = GetBuffer() + f * width + y * width * numFrames;
			for (int x = 0; x < width; ++x) if (addr[x])
			{
				start[f][y] = x;
				break;
			}
		}
	}
}

// EOF